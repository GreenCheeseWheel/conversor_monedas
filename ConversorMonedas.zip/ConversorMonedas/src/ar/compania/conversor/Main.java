package ar.compania.conversor;

/*Exchange rates API
*
* Key: 51fa13e831f59b185c18d23e
* Per month requests: 1500
*
**/


/**
 * @author TheGr
 *
 * Este programa conversor utiliza la ExchangeRates-API, cuya documentación se encuentra disponible
 * en {@link "https://www.exchangerate-api.com/docs/overview"}
 *
 * Además, hace uso extensivo de la librería Swing, para la cual existe documentación
 * disponible en {@link "https://docs.oracle.com/javase/7/docs/api/javax/swing/package-summary.html"}
 *
 * Tutorial parser: https://jenkov.com/tutorials/java-json/jackson-jsonparser.html#parsing-json-with-the-jsonparser
 */

public class Main {

    public static void main(String[] args) {

        new Screen();

    }
}
