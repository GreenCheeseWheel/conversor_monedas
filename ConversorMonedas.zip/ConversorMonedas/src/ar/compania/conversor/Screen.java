package ar.compania.conversor;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * La clase Screen existe con el solo propósito de mostrar los elementos relativos a JOptionPane,
 * y para esto hace uso de la interfaz ActionListener, tal de poder oir los eventos relativos a la ComboBox
 * que muestra opciones de conversión de divisas.
 *
 *
 * */

public class Screen  implements ActionListener {
    /**
     *La propiedad String[] divisas corresponde cada índice a un tipo de conversión.
     * Desde divisas[0] hasta divisas[4] especifíca una conversión de ARS a otra moneda. A partir de divisas[5] se hace la conversión contraria.
     **/

    String[] divisas = {"ARS a Euros", "ARS a Libras Esterlinas", "ARS a Yenes", "ARS a Wones Surcoreanos", "ARS a Dólares", "Euros a ARS", "Libras Esterlinas a ARS", "Yenes a ARS", "Wones Surcoreanos a ARS", "Dólares a ARS"};

    JComboBox<String> comboBox = new JComboBox<>(divisas);
    int indiceComboBox = 0;
    float cantidadDineroUno, cantidadDineroDos;

    Screen() {

        comboBox.addActionListener(this);


        cantidadDineroUno = Float.parseFloat( JOptionPane.showInputDialog("Ingrese la cantidad de dinero a convertir") );

        JOptionPane.showMessageDialog(null, comboBox, "Elija las divisas para la conversión", JOptionPane.QUESTION_MESSAGE);

        cantidadDineroDos = ConversorDivisas.convertirDivisa(indiceComboBox, cantidadDineroUno);

        JOptionPane.showMessageDialog(null, cantidadDineroUno + " " + divisas[indiceComboBox] + ": " + cantidadDineroDos);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == comboBox) {
            indiceComboBox = comboBox.getSelectedIndex();
        }
    }

}
