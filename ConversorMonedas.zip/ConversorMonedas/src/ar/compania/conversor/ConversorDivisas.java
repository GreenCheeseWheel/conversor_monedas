package ar.compania.conversor;


/*
* Divisas: ARS, EUR, GDP, JPY, KRW, USD
*
* Ordenadas alfabéticamente para facilitar el uso de índices en los arrays.
* Así, 0 es el índice de ARS, mientras que 5 es el de USD
* */

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public abstract class ConversorDivisas {

    private static final JsonFactory factory = new JsonFactory();
    private static JsonParser parser;
    private static String[] divisas = {"EUR", "GDP", "JPY", "KRW", "USD"};


    /**
     * convertirDivisa(int indicePartida, float cantidadDinero) devuelve -1.0f en caso de error en la conexión a la API.
     *
     * @param indicePartida
     * @param cantidadDinero
     * @return float
     */
    public static float convertirDivisa(int indicePartida, float cantidadDinero) {

        int indice = indicePartida % 5;
        float valorRetorno = -1.0f;

        String divisa;
        String url_str;
        URL url;
        HttpURLConnection con = null;

        if(indicePartida <= 4) {
            url_str = "https://v6.exchangerate-api.com/v6/51fa13e831f59b185c18d23e/latest/ARS";
            divisa = "ARS";
        } else {
            url_str = String.format("https://v6.exchangerate-api.com/v6/51fa13e831f59b185c18d23e/latest/%s", divisas[indice]);
            divisa = divisas[indice];
        }


        try {
            url = new URL(url_str);
            con = (HttpURLConnection) url.openConnection();
            con.connect();

            parser = factory.createParser(new InputStreamReader((InputStream) con.getContent()));


            while (!parser.isClosed()) {
                JsonToken token = parser.nextToken();

                if (JsonToken.FIELD_NAME.equals(token)) {
                    String fieldName = parser.getCurrentName().toString();

                    token = parser.nextToken();


                    if (divisa.equals("ARS") && fieldName.equals(divisas[indice])) {
                        valorRetorno = (float) parser.getValueAsDouble() * cantidadDinero;
                    }

                    else if (!divisa.equals("ARS") && fieldName.equals("ARS")) {
                        valorRetorno = (float) parser.getValueAsDouble() * cantidadDinero;
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            if(con != null) { con.disconnect();}

        } finally {

            return valorRetorno;
        }
    }

}
